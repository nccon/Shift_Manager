# Shift-Planner
 Manage your shifts (Add and edit users, Admin privileges, Notify user by SMS, Swap Shifts)
